Se adjunta un Makefile con dos opciones de compilación:
-Con make nasm se compilan los .c, se ejecutan generando los .asm y estos son compilados generando el ejecutable.
-Con make solo se compilan los .c.